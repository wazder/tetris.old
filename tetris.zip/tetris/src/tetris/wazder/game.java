// tetris.wazder
// Hasan Tatar , y23lbim801 , 27 dec 2023 , oop icu
package tetris.wazder;

import javax.swing.*;
import java.awt.*;

public class game extends JFrame {
    public game() {

        initialiseUI();
    }

    private void initialiseUI() {

        var board = new board();
        add(board);
        board.setStarted();

        setTitle("Tetris Game by wazder");
        setSize(400, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {

            game game = new game();
            game.setVisible(true);
        });
    }
}